# Media License

## Images

All image files in this project are licensed under [Creative Commons Attribution 4.0 International](https://choosealicense.com/licenses/cc-by-4.0/)

## Music

Music by Juhani Junkala at [Open Game Art](https://opengameart.org/content/5-chiptunes-action)